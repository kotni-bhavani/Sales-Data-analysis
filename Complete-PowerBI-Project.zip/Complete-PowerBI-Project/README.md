
# Sales & Revenue Analysis Dashboard

## Tools Used
- SQL
- Power BI
- Excel

## Project Features
- Total Sales KPI
- Profit Analysis
- Regional Sales Dashboard
- Product Performance

## Steps
1. Open Power BI Desktop
2. Import retail_sales.csv
3. Create KPI cards
4. Add charts
5. Save as sales_dashboard.pbix

## GitHub Upload Files
- Dataset
- SQL Queries
- Dashboard Screenshot
- README
