
CREATE DATABASE sales_dashboard;
USE sales_dashboard;

CREATE TABLE retail_sales (
Order_ID INT,
Order_Date DATE,
Customer_Name VARCHAR(100),
Region VARCHAR(50),
Product VARCHAR(100),
Category VARCHAR(100),
Quantity INT,
Sales FLOAT,
Profit FLOAT,
Payment_Mode VARCHAR(50)
);

SELECT SUM(Sales) AS Total_Sales FROM retail_sales;

SELECT SUM(Profit) AS Total_Profit FROM retail_sales;

SELECT Region, SUM(Sales)
FROM retail_sales
GROUP BY Region;

SELECT Product, SUM(Sales)
FROM retail_sales
GROUP BY Product
ORDER BY SUM(Sales) DESC
LIMIT 5;
